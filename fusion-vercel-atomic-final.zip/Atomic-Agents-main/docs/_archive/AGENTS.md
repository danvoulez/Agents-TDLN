# AI Coding Team Agents

- Modes: mechanic (strict budgets), genius (exploratory).
- Always act via tools; never mutate without a plan.
- Record analysis, plan, and results as events tied to jobs.
- Escalate to human when intent or safety is unclear.
