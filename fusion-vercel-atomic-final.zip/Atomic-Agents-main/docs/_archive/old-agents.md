# Agents

Agents live in `packages/agents` and compose tools to plan, build, review, and evaluate work. The untrusted brain contract is kept in `prompts/contracts.ts`.
