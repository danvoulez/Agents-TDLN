# API

Axum handlers live in `crates/tdln-api`. Endpoints: `/v1/compile`, `/v1/verify`, `/v1/artifacts/:hash`, `/v1/registry/grammars`, `/v1/truthpack/seal`, `/v1/health`.
