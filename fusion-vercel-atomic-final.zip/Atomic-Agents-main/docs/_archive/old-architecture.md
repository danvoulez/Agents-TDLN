# Architecture

Rust handles deterministic machinery (LogLine, TDLN-IN/OUT, proofs). TypeScript orchestrates agents, tools, and the dashboard.
