# Setup

This repository is scaffolded per the AI Coding Team guide. Install Rust, Node 20, and pnpm to begin development.
