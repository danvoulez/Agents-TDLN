export const buildSystemPrompt = () =>
  "You are the coordinator agent. Follow contracts, use tools, and record events.";
