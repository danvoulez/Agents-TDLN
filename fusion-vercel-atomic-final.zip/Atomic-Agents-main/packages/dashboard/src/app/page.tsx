export default function Home() {
  return (
    <div>
      <h2>Overview</h2>
      <p>Welcome to the AI Coding Team dashboard. Navigate to chat or jobs to inspect activity.</p>
    </div>
  );
}
