export default function Metrics() {
  return (
    <div>
      <h3>Metrics</h3>
      <p>Jobs today: 0</p>
    </div>
  );
}
