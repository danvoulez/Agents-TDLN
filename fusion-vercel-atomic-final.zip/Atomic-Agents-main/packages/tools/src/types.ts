import { Tool } from "@ai-coding-team/types";

export type GenericTool = Tool<any, any>;
